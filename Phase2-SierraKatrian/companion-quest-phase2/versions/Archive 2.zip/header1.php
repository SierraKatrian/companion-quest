<?php

?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Companion Quest</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <!-- Font Awesome icons -->
        <script src="https://use.fontawesome.com/2d7fe5a6b4.js"></script>
        <!-- CUSTOM CSS STYLESHEETS -->
        <link rel="stylesheet" href="css/global.css">
        <link rel="stylesheet" href="css/header-and-footer.css">
        <link rel="stylesheet" href="css/create-a-game.css">

    </head>

    <body>
        
        <header>
            <nav class="container-fluid">                  
                <ul class="nav-row row content-wrapper">
                    <li class="nav-containers col-md-1 text-left"><a href="index.php">home</a></li>
                    <li class="start-quest-link nav-containers col-md-4 text-left"><a href="#" data-toggle="modal" data-target="#RegisterSignInModal">START QUEST</a></li>
                    <div class="logo-container col-md-2 text-center"><a href="#"><img class="companionquest-logo" src="img/global/CompanionQuestLogo.png" alt="Companion Quest Logo" /></a></div>
                    <li class="nav-containers col-md-5 text-right"><a href="#" data-toggle="modal" data-target="#RegisterSignInModal">register | sign-in</a></li>
                </ul>
            </nav>
        </header>
        
<?php
        
include "register-sign_in.php";
        
?>