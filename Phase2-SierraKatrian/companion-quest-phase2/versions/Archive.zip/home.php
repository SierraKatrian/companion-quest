<?php

?>

<head>
    <link rel="stylesheet" href="css/home.css">
</head>

<div class="jumbotron">
    <div class="container-fluid">
        <div class="row content-wrapper">
            <div class="col-md-6 jumbotron-text">
                <h1>From Tabletop To Desktop!</h1> 
                <p>Designed to bring people together and enhance the way we play tabletop roleplaying games.</p> 
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#RegisterSignInModal">register / sign-in!&nbsp;&nbsp;<span class="glyphicon glyphicon-chevron-right"></span></button>
            </div>
            <div class="col-md-6">
                <img class="companionquest-banner" src="img/global/companionQuestBanner.png" alt="Companion Quest Banner" />
            </div>
        </div>
    </div>
</div>

<!-- OUR GAMES -->

<div class="container-fluid">
    <div class="row body-content content-wrapper">
        <div class="col-md-12">
            <h2>Our Games</h2>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row body-content content-wrapper">

        <!-- Apocalypse World Section -->

        <div class="col-md-6">
            <br />
            <img class="apocalypse-world-img" src="img/home/apocalypse-world-thumb.jpg" alt="Apocalypse World Thumb" />
            <h3>Nobody remembers how or why.</h3>
            <br />
            <p>
                The oldest living survivors have childhood memories of it: cities burning, 
                society in chaos then collapse, families set to panicked flight, the weird 
                nights when the smoldering sky made midnight into a blood-colored half-day.
            </p>
            <p>
                Now the world is not what it was. Look around you: evidently, certainly, 
                not what it was. But also close your eyes, open your brain: something
                is wrong.
            </p>
            <br />

            <!-- Apocalypse World Rulebook Modal -->

                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#ApocalypseModal"><span class="glyphicon glyphicon-file"></span>&nbsp;view rulebook</button>

                <div id="ApocalypseModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></button>
                                <object width="525" height="500" data="pdf/Apocalypse-World-Rulebook.pdf"></object>
                            </div>
                        </div>
                    </div>
                </div><!-- END of Apocalypse World Rulebook Modal -->
        </div>

        <!-- Dungeon World Section -->

        <div class="col-md-6">
            <br />
            <img class="dungeon-world-img" src="img/home/dungeon-world-thumb.jpg" alt="Dungeon World Thumb" />
            <h3>Classic fantasy adventure. </h3>
            <br />
            <p>
                Explore a land of magic and danger in the roles of adventurers searching for 
                fame, gold, and glory. Delve into goblin holes or chance a dragon's lair. 
                Dungeon World takes classic fantasy and approaches it with new rules.                    </p>
            <p>
                Dungeon World's simple rules happen based on what's happening within the game, 
                so you spend more time talking about the action and less time talking about the 
                rules.
            </p>
            <br />

                <!-- Dungeon World Rulebook Modal -->

                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#DungeonModal"><span class="glyphicon glyphicon-file"></span>&nbsp;view rulebook</button>

                <div id="DungeonModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></button>
                                <object width="525" height="500" data="pdf/Dungeon-World-Rulebook.pdf"></object>
                            </div>
                        </div>
                    </div>
                </div> <!-- END of Dungeon World Rulebook Modal -->
        </div>

    </div>
</div> <!-- END of OUR GAMES -->

<!-- OUR STORY -->

<div class="container-fluid">
    <div class="row body-content content-wrapper">
        <div class="col-md-12">
            <br />
            <h2>Our Story</h2>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row body-content content-wrapper">

        <div class="col-md-6">

            <h3>Classic fantasy adventure.</h3>
            <br />
            <p>
                Explore a land of magic and danger in the roles of adventurers searching for 
                fame, gold, and glory. Delve into goblin holes or chance a dragon's lair. 
                Dungeon World takes classic fantasy and approaches it with new rules.                    
            </p>
            <p>
                Dungeon World's simple rules happen based on what's happening within the game, 
                so you spend more time talking about the action and less time talking about the 
                rules.
            </p>

        </div>

    </div>
</div>

<div class="container-fluid">
    <div class="row content-wrapper">
        <div class="col-md-1 bg-warning">
            1
        </div>
        <div class="col-md-1 bg-info">
            2
        </div>
        <div class="col-md-1 bg-danger">
            3
        </div>
        <div class="col-md-1 bg-success">
            4
        </div>
        <div class="col-md-1 bg-warning">
            5
        </div>
        <div class="col-md-1 bg-info">
            6
        </div>
        <div class="col-md-1 bg-danger">
            7
        </div>
        <div class="col-md-1 bg-success">
            8
        </div>
        <div class="col-md-1 bg-warning">
            9   
        </div>
        <div class="col-md-1 bg-info">
            10
        </div>
        <div class="col-md-1 bg-danger">
            11
        </div>
        <div class="col-md-1 bg-success">
            12
        </div>
    </div>
</div>
