        <footer>
            <div class="container-fluid">
                <nav class="nav-row row content-wrapper" role="navigation">
                    <div class="col-md-6">
                        <li><a href="faq.php">FAQ&nbsp;</a></li>
                        <li><a href="contact.php">Contact&nbsp;</a></li>
                        <li><a href="legal.php">Legal&nbsp;</a></li>                    
                    </div>
                    <div class="col-md-6 text-right">
                        <li><a href="faq.php"><i class="fa fa-facebook-official fa-lg" aria-hidden="true"></i></a></li>
                        <li><a href="contact.php"><i class="fa fa-twitter fa-lg" aria-hidden="true"></i></a></li>
                        <li><a href="legal.php"><i class="fa fa-twitch fa-lg" aria-hidden="true"></i></a></li> 
                    </div>
                </nav>
            </div>
        </footer>
    </body>
</html>