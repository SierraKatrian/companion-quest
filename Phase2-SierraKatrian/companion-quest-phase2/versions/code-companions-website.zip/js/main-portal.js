$(document).ready(function(){
        
    $('[data-toggle="tooltip"]').tooltip(); 
    
    $('td').click(function(){
        window.location.href = "player-portal.php";    
    })
    
}); 